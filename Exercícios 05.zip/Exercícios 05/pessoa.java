public class pessoa {
    protected String nome;
    protected int idade;

    public pessoa (String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void apresentar() {
        System.out.println("Nome:" + nome);
        System.out.println("Idade: " + idade);
    }

}