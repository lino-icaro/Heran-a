public class escola {
    public static void main(String[] args) {
        pessoa aluno = new aluno("aluno", 15, "curso");
        pessoa professor = new professor("Professor", 35, "Diciplina");

        pessoa[] pessoas = {aluno, professor};

        for (pessoa pessoa : pessoas) {
            System.out.println("--------------------");
            pessoa.apresentar();
        }
    }
    
}
