public class professor extends pessoa {
    private String diciplina;
    

    public professor(String nome, int idade, String diciplina) {
        super(nome, idade);
        this.diciplina = diciplina;
    }

    @Override
    public void apresentar() {
        System.out.println("PROFESSOR");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Diciplina: " + diciplina);
    }
}
